GIB2A - Xicoy ProHub Widget - V1.1

Installation:
1. Extract this ZIP.
2. Copy the SCRIPTS folder to the root of the radio SD card.
3. Final required path:
   SCRIPTS/GIB2A/main.lua
4. Reboot the radio.
5. Add the widget from:
   Model -> Display -> Widgets

Notes:
- Do not create an extra nested folder.
- This ZIP was built from the uploaded main.lua file.
